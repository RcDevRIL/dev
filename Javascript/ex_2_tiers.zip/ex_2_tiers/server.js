var net = require('net');

var HOST = '127.0.0.1'; // On écoute sur toutes les interfaces
var PORT = 3333;

var server = net.createServer();

server.on('connection', onClientConnection);
server.on('listening', onListening);
server.on('error', onError);

server.listen(PORT, HOST);

function onClientConnection(client) {

  console.log('Nouveau client depuis %s:%s', client.remoteAddress, client.remotePort);

  // On souhaite commencer à récupérer les données
  // provenant de ce nouveau client
  client.on('data', onClientData);
  client.on('close', onClientClose);

  function onClientData(data) {

    // Les données sont reçues sous forme de bytes. On les transforme
    // en chaine de caractères UTF-8 pour faciliter leur manipulation
    var str = data.toString('utf8');

    console.log('Données reçues de %s:%s: "%s"', client.remoteAddress, client.remotePort, str);

    // TODO désérialiser les données reçues et traiter les opérations.

  }

  function onClientClose() {
    console.log('Le client %s:%s s\'est déconnecté.', client.remoteAddress, client.remotePort);
  }

}

function onListening() {
  console.log("Serveur en écoute sur %s:%s", HOST, PORT)
}

function onError(err) {
  console.log('Une erreur a été soulevée: %s', err);
  process.exit(1);
}
